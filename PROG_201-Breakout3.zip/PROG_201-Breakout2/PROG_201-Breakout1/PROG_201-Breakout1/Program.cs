﻿using System;
using static System.Console;

namespace PROG_201_Breakout1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Title = "Crafting Demo!";
            Engine engine = new Engine();
            engine.Play();
        }
    }
}