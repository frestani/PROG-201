﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROG_201_Breakout1
{
    public class Recipe
    {
        public List<Item> RecipeRequirements = new List<Item>();

        public Item Result = new Item();

    }
}