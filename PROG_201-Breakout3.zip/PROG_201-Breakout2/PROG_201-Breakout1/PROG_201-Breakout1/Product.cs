﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PROG_201_Breakout1
{
    public class Product: Item
    {
    }
}