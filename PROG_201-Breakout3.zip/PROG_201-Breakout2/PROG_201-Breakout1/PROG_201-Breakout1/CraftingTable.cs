﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static PROG_201_Breakout1.Utility;

namespace PROG_201_Breakout1
{
    public class CraftingTable
    {
        public List<Recipe> recipes = new List<Recipe>();
        public CraftingTable()
        {
            Recipe recipe1 = new Recipe();
            recipe1.RecipeRequirements = LoadItemsFromTextFile("../../../data/recipes.txt");
            recipe1.Result = new Item() { Name = "", Amount = 1 };


            recipes.Add(recipe1);
        }

        public Item Craft(Recipe recipe)
        {

            return recipe.Result;
        }

        //example of return with no rturn type:
        public void About()
        {
            return;
        }
    }
}