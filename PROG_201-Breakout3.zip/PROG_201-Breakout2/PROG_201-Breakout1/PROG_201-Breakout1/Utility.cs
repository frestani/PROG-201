﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection.Metadata.Ecma335;

namespace PROG_201_Breakout1
{
    internal class Utility
    {
        public static void Print(string message)
        {
            Console.WriteLine(message);
        }

        public string ConvertToLower(string message)
        {
            return message.ToLower();
        }
        //alternative
        //public string ConvertToLower(string message) => message.ToLower();

        public int ConvertToInt(string input)
        {
            return Convert.ToInt32(input);
        }
      /*  public static string LoadTextFromTextFile(string path)
        {
            if (File.Exists(path))
                return File.ReadAllText(path);

            return "Data was not found";
        }
      */

        public static List<Item> LoadItemsFromTextFile(string path)
        {
            List<Item> items = new List<Item>();

            if (File.Exists(path))
            {
                string[] itemNames = File.ReadAllLines(path);
                for(int i = 0; i < itemNames.Length; i+=2)
                {
                    Item item = new Item();
                    item.Name = itemNames[i];
                    int amount = 0;
                    try
                    {
                        amount = Convert.ToInt32(itemNames[i + 1]);
                    }
                    catch { }
                    item.Amount = amount;
                    items.Add(item);
                    i++;
                }
            }
            return items;
        }
        
    }
}
