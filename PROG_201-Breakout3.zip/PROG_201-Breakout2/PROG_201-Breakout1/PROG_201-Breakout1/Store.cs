﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG_201_Breakout1
{
    public class Store
    {
        double currency = 500.00;
        List<Item> StoreItems = new List<Item>();

        //sell to player
        //show items
        //allow player to select items
        //currency change


    }
}
