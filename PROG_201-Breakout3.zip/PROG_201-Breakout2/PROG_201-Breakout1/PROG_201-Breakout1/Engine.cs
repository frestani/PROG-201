﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static PROG_201_Breakout1.Utility;

namespace PROG_201_Breakout1
{
    internal class Engine
    {
        Player playerOne = new Player() { Name = "Fran", Inventory = new List<Item>() { 
            new Item() { Name = "Water"},
            new Item() { Name = "Berries"}
        } };
        Player playerTwo = new Player()
        {
            Name = "Fran",
            Inventory = new List<Item>() {
            new Item() { Name = "Water"},
            new Item() { Name = "Berries"}
        }
        };
        Player store = new Player() { Name = "Main Store", Inventory = new List<Item>()
        {
            new Item() { Name = "Cheese"}
        }
        };
        CraftingTable craftingtable = new CraftingTable();

        private void SetUpPlayers()
        {
            //playerOne.Name = LoadTextFromTextFile("../../../data/playerOneName.txt");
            //playerTwo.Name = LoadTextFromTextFile("../../../data/playerTwoName.txt");
            //craftingtable.recipes = LoadItemsFromTextFile();

        }

        public void Play()
        {
            double price = 3.99;

            Print("Hello World"); //setting up for a delegate later
            Print("Hello " + player.Name); //concatenation
            Console.WriteLine("Hello {0}", player.Name); //composite
            Print($"Hello {player.Name}"); //interpolation

            Print($"I paid {price.ToString("c")} for this coffee");

            player.setPlayerName("Max");
            Menu();
            Console.ReadKey();        
        }
        private void Menu()
        {
            Print("Menu");
            Print("1: Show Inventory");
            Print("2: Trade");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    Print(player.ShowInventory());
                    break;
                case "2":
                    Print(store.ShowInventory(true));
                    break;
            }
            Console.ReadKey();
            Menu();
        }
       
    }

}